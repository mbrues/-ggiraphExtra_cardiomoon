This is an update of the package 'ggiraphExtra'

## Test environments
* local OS X install, R 4.0.2
* win-builder (devel and release)

## R CMD check results
There were no ERRORs or WARNINGs.

